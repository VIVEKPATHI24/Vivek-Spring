package com.example.allocation.Repository;


import com.example.allocation.Order.OrderDto;
import org.springframework.stereotype.Repository;

@Repository
public class AllocationRepo {



}
