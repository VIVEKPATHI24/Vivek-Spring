package com.example.allocation.Order;

public class SellingChannel {
    private Long id;
    private Long sellingChannelId;
    private String sellingChannelName;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSellingChannelId() {
        return sellingChannelId;
    }

    public void setSellingChannelId(Long sellingChannelId) {
        this.sellingChannelId = sellingChannelId;
    }

    public String getSellingChannelName() {
        return sellingChannelName;
    }

    public void setSellingChannelName(String sellingChannelName) {
        this.sellingChannelName = sellingChannelName;
    }

}

