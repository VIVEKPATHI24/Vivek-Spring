package com.example.Item.domain.common;

public enum ItemStatus {

    Active,
    NotActive

}
